---
name: build-persona
description: Build or update a grounded persona file from real research evidence, in the format the persona-lab tests expect. Use when the user wants to create a persona, add evidence, or fix a persona that failed lint.
---

# Build a grounded persona

A persona here is a behavior model whose every claim points at real evidence. Demographics alone make generic personas, and claims without evidence are the model's inventions.

## Before you start

- Ask which real interviews are **held out**. Those live in `holdout/` and you must not read or use them. If none exist, say so plainly: the persona will be `uncalibrated` until some do. Suggest holding out roughly a fifth to a third of interviews, and enough to yield at least 10 held-out answers.
- Confirm the source material is real (interview notes, transcripts, survey free text, tickets) and that the client's data terms allow it to be processed here.

## Steps

1. **Extract evidence.** Add verbatim quotes (one or two sentences each) to `evidence/evidence.json` with a new id, the source id, and `"synthetic": false`. Do not paraphrase, merge, or tidy a quote. Never add model-generated text.
2. **Draft claims** in `personas/<id>.md` using the format in `personas/dana_charge_nurse.md`:
   - `- [E3, E7] behavior: one fact per line.`
   - Categories: `behavior`, `workaround`, `constraint`, `distrust`, `goal`, `context`. Aim for at least three behavioral claims; a persona without them yields generic answers.
   - Cite two or more evidence ids when the material supports it. If a claim has no evidence, write `[]` and tell the user it is an inference.
   - Do not embellish. No names of tools, numbers or backstory the evidence doesn't contain.
3. **Lint:** `scripts/persona-lab lint --persona personas/<id>.md --evidence evidence/evidence.json --out calibration/<id>/lint`
4. Fix errors (missing ids, circular evidence). Report warnings rather than hiding them.

## Reply with

The number of claims, the share that are grounded and the share with two or more evidence items, and a short list of ungrounded or thin claims the user may want to firm up with more research. State that the persona is `uncalibrated` until `calibrate-persona` has run against holdout interviews.
