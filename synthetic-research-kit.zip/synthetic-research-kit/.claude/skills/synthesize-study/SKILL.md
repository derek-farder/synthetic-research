---
name: synthesize-study
description: Code the synthetic interview transcripts, write the study synthesis as hypotheses with provenance tags, run the skeptic review and the provenance checker. Use after run-interview has produced transcripts.
---

# Synthesize a study

The output is a set of hypotheses and a plan to test them with real people. It is not a findings report.

## Steps

1. **Read** `question.md`, `protocol.md`, `hypotheses.md` and every file in `runs/`.
2. **Open-code** each transcript into `coding.md`: a theme list with, per theme, which runs and which personas contain it (file names). Code what was said, not what you expected. Record where answers surprised the expectations in `hypotheses.md`, and where they merely confirmed them.
3. **Write `synthesis.md`** from `studies/_template/synthesis.md`. Keep every required section:
   - `## Hypotheses`: each bullet ends with `[support: N runs / M personas]`. A bullet supported by a single run says "single run" in the text.
   - `## Single-persona observations`: what only one persona said, kept separate so it isn't mistaken for a pattern.
   - `## Surprises and misses`: where results differed from `hypotheses.md`, and what the protocol failed to elicit.
   - `## Validate with real people`: for each hypothesis, the concrete real-research question and method that would test it.
   - `## Limits`: agreeableness, averaging, stated-vs-revealed behavior, fluent overconfidence; plus one line per persona, exactly in this form:
     `Calibration: <persona id>: <status>` using the status from `calibration/<id>/STATUS.md` (`uncalibrated` if the file is absent).
4. **Provenance:** every quote is a blockquote ending with `[SYN: runs/<file>.md]` (or `[REAL: E<n>]` if you cite real evidence). Paraphrase without quotes where you can. Never write "participants said", "research shows" or sizes and rates that need a real sample.
5. **Skeptic review.** Delegate to the `skeptic` subagent with the study folder path. Read `skeptic-review.md`. Downgrade, reword or remove every hypothesis it marks `UNSUPPORTED`, and flag `WEAK` ones as such in the synthesis. Do not argue with the skeptic by hiding its objections; summarize unresolved ones in `## Limits`.
6. **Check:** `python3 scripts/check_study.py studies/<study>`. Fix every error. Re-run the skeptic only if you changed hypotheses materially.

## Reply with

Three to five sentences: the hypotheses that survived and how strong they are, the biggest thing the skeptic raised, and the first real-research step you'd take. Point to the files. Do not paste the synthesis.
