---
name: run-interview
description: Run the approved interview protocol against synthetic personas using the persona-runner subagent, one question at a time, and save tagged transcripts to the study's runs folder. Use after plan-study has been approved.
---

# Run interviews

## Preconditions

- `studies/<study>/protocol.md` has `status: approved`. If not, stop and send the user back to `plan-study`.
- The personas named in the protocol exist.

## Blind rule

Each call to `persona-runner` contains only:

```
Persona file: personas/<file>.md
Transcript so far:
<prior Q and A, or "(none)">
Next question: <the question>
```

Nothing about the study's purpose, `hypotheses.md`, other personas' answers or what you are hoping to hear. The subagent is stateless; the transcript you pass is its memory.

## Procedure

For each persona x run `r` (default 3 runs), apply that run's framing from the protocol (for example neutral, adversarial interviewer, rushed, rapport-heavy) by changing how *you* phrase questions, not by telling the subagent about it.

1. Ask the core questions in order. At each question step, delegate all persona-runs in parallel (one `persona-runner` call per persona-run in the same turn), then append each answer to that run's transcript.
2. After each answer, decide whether a follow-up probe from the protocol is warranted. Mark follow-ups `P` in the transcript. Include the contradiction probe at least once per interview.
3. Do not edit, merge or clean up answers. If an answer is clearly broken (breaks character, mentions being simulated), re-ask once and note the retry in the transcript.

Cost note: a full interview is one subagent call per question per run. For a rough shakedown of a new guide, you may run a single run per persona first and tell the user it is a shakedown, not a study.

## Transcript format

Save each run as `studies/<study>/runs/<persona>-r<N>.md`:

```
---
synthetic: true
persona: <persona id>
run: <N>
framing: <framing used>
protocol: protocol.md
---
> SYNTHETIC TRANSCRIPT. Simulated by a language model from a persona file. Not a research participant.

**Q1:** <question>
**A1 (<persona>, synthetic):** <answer>

**Q1P:** <follow-up>
**A1P (<persona>, synthetic):** <answer>
```

## Finish

Run `python3 scripts/check_study.py studies/<study>` and fix any transcript errors. Reply with how many transcripts and turns were produced, any retries, and anything that looked off (for example a persona that agreed with every leading question). Do not analyze content here; that is `synthesize-study`.
