---
name: calibrate-persona
description: Calibrate a persona against held-out real interviews and run coherence probes, then record its calibration status. Use when the user wants to know whether a persona can be trusted, after a persona or its evidence changes, or before running a study.
---

# Calibrate a persona

Calibration compares what the persona says to what real participants said in interviews it never saw, and checks that it is consistent, resists leading questions, hedges when it doesn't know, and differs from other personas.

## Preconditions (stop and tell the user if any fails)

- `test -n "$ANTHROPIC_API_KEY"`. The harness calls the API directly. **Never substitute `--mock`**: a mock run is a plumbing test and cannot produce a calibration status.
- A holdout file exists for this persona: `ls holdout/` (you cannot read it, and should not try). Its `persona_id` must match.
- A probe file exists at `calibration/probes/<id>.json` (format: `tools/persona-lab/README.md`). If not, draft one with consistency questions, neutral/leading-positive/leading-negative triples, out-of-scope questions and distinct questions for this persona's domain, and ask the user to review it before you run anything.
- Suggest `PERSONA_LAB_JUDGE_MODEL` set to a different model than the persona model when one is available.

## Run

```
scripts/persona-lab all --persona personas/<id>.md --others personas \
  --evidence evidence/evidence.json --holdout holdout \
  --probes calibration/probes/<id>.json --out calibration/<id>/<YYYY-MM-DD>
```

Exit code 1 means a FAIL, 2 means the holdout leaked into the evidence. Both are results, not crashes.

## Record the status

Read `calibration/<id>/<date>/results.json` (`overall`, `sections.backtest.summary.n_turns`) and compute the persona hash: `sha256sum personas/<id>.md | cut -c1-12`.

Status rules:
- `overall` is `INVALID` → `uncalibrated` (holdout leaked; fix the evidence/holdout split first)
- `overall` is `FAIL` → `failed`
- `PASS` or `WARN` with fewer than 10 held-out answers → `low-power`
- `PASS` or `WARN` with 10 or more → `calibrated`

Write `calibration/<id>/STATUS.md`:

```
---
status: <status>
date: <YYYY-MM-DD>
overall: <PASS|WARN|FAIL|INVALID>
persona_sha256: <12 hex chars>
---
Report: calibration/<id>/<date>/report.md
Reliable for: <behaviors/topics where tests passed>
Not reliable for: <tests that failed or warned, in plain words>
```

## Reply with

The table of verdicts, the status, and the two or three things the user should read in the report first (usually the real-vs-synthetic answers that diverged). Say that `calibrated` means "not visibly broken against the holdout we had", never "valid". Remind them the status goes `stale` automatically if the persona file changes, and calibration should be rerun.

If you or the user edit the persona after seeing its holdout results, that holdout is now contaminated for this persona. Say so and recommend fresh holdout data.
