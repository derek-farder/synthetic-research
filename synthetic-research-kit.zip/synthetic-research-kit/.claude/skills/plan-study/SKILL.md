---
name: plan-study
description: Plan a synthetic research study - create the study folder, write the question and a neutral discussion guide, choose personas and run plan, then stop for the user's approval. Use when the user wants to research a question against the synthetic personas or test an interview guide.
---

# Plan a study

This is the front half of the researcher loop. It ends at an approval gate. Do not run any interviews in this skill.

## Steps

1. **Check the personas.** List `personas/` and read `calibration/<id>/STATUS.md` for each candidate. Tell the user each persona's status. Personas that are `uncalibrated`, `stale` or `failed` can still be used for guide-testing, but the plan must say so.
2. **Create the folder** `studies/<YYYY-MM-topic>/` from `studies/_template/` (copy `question.md`, `hypotheses.md`, `protocol.md`, `synthesis.md`; create `runs/`).
3. **`question.md`:** the decision this informs, the research question, what would change the team's mind, and what this study cannot tell us.
4. **`hypotheses.md`:** the researcher's own expectations, written *before* interviews. These stay with you. The persona-runner never sees them.
5. **`protocol.md`** (set `status: draft` in its frontmatter):
   - 6 to 10 core questions, behavior first ("Tell me about the last time...") before attitudes, hypotheticals last.
   - Neutral wording. No question that names the answer, flatters the product, or offers a yes/no on what you hope is true.
   - Follow-up probes for each question.
   - At least one probe designed to expose a contradiction or a workaround ("You mentioned X earlier; what happens when...").
   - Personas to interview and why; runs per persona (default 3); framing variation per run (neutral, adversarial, rushed, rapport-heavy); the transcript naming convention `runs/<persona>-r<N>.md`.
   - What a real study would add (the validation plan stub).
6. **Stop.** Summarize the plan in a few lines and ask the user to approve or change it. Only when they approve, set `status: approved` in `protocol.md`.

## Reply with

The study folder path, the personas and their calibration status, the number of interview turns this will cost (personas x runs x questions, plus probes), and the one question in the guide you are least sure about.
